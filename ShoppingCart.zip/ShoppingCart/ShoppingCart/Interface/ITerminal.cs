﻿namespace ShoppingCart.Interface
{
    /// <summary>
    /// Terminal interface where the items are scanned
    /// </summary>
    public interface ITerminal
    {
        /// <summary>
        /// Method to scan the products
        /// </summary>
        /// <param name="item">Set of products that are scanned</param>
        void Scan(string item);

        /// <summary>
        /// Provides the total pricing of the scanned product
        /// </summary>
        /// <returns>Total Price</returns>
        decimal Total();
    }
}
