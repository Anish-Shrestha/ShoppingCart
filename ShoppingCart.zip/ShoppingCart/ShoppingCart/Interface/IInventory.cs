﻿using System.Collections.Generic;
using ShoppingCart.Model;

namespace ShoppingCart.Interface
{
    /// <summary>
    /// Interface for the inventory
    /// </summary>
    public interface IInventory
    { 
        /// <summary>
        /// This method gets the inventory products
        /// </summary>
        /// <returns>List of products</returns>
        public List<Product> GetProducts();
    }
}
