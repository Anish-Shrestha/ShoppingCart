﻿namespace ShoppingCart.Interface
{
    /// <summary>
    /// Interface for price generators
    /// </summary>
    public interface IPriceGenerator
    {
        /// <summary>
        /// Generates the price for the total number of given product
        /// </summary>
        /// <param name="pCodeCount">Total number of product that is scanned in terminal</param>
        /// <returns>Price</returns>
        public decimal Generate(int pCodeCount);
    }
}
