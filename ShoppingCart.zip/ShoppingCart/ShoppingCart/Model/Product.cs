﻿using System.Collections.Generic;

namespace ShoppingCart.Model
{
    /// <summary>
    /// Represents a class to store the product information of the shop
    /// </summary>
    public class Product
    {
        /// <summary>
        /// Product code of the product
        /// </summary>
        public char ProductCode { get; set; } 

        /// <summary>
        /// Price of the product
        /// </summary>
        public decimal Price { get; set; } 

        /// <summary>
        /// List of Volume size and their respective discount price
        /// </summary>
        public List<VolumeProductPrice> VolumeProductPrices { get; set; }

        /// <summary>
        /// Initialize the product class with out volume products information
        /// </summary>
        /// <param name="productCode">Product Code of the product</param>
        /// <param name="price">Price of the product</param>
        public Product(char productCode, decimal price) : this(productCode, price, null, null)
        {
        }

        /// <summary>
        /// Initialize the product class with a single volumeSize and volumePrice information
        /// </summary>
        /// <param name="productCode">Product Code of the product</param>
        /// <param name="price">Unit price of the product</param>
        /// <param name="volumeSize">Product Volume Size</param>
        /// <param name="volumePrice">Product Volume Price</param>
        public Product(char productCode, decimal price, int? volumeSize, decimal? volumePrice)
        {
            ProductCode = productCode;
            Price = price;

            if(volumeSize is > 0 && volumePrice is not null)
                AddVolumeProductPrice(volumeSize.Value, volumePrice.Value);

        }

        /// <summary>
        /// This method allows to add more volume and price information of the product
        /// </summary>
        /// <param name="size">Volume size of the product</param>
        /// <param name="price">Volume price of the product</param>
        public void AddVolumeProductPrice(int size, decimal price)
        {
            VolumeProductPrices ??= new List<VolumeProductPrice>();

            VolumeProductPrices.Add(new VolumeProductPrice(size,price));

        }

    }
}
