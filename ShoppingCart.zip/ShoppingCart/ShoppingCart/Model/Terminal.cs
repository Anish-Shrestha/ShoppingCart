﻿using ShoppingCart.Interface;
using ShoppingCart.Model.PriceGenerator;
using System.Linq;
using System.Text;

namespace ShoppingCart.Model
{
    /// <summary>
    /// This class represents the terminal
    /// </summary>
    public class Terminal: ITerminal
    {
        /// <summary>
        /// Inventory information of the shop
        /// </summary>
        private readonly IInventory _inventory;

        /// <summary>
        /// Stores all the scan item in the terminal
        /// </summary>
        private readonly StringBuilder _productCodes;

        /// <summary>
        /// Constructor to initialize the Terminal class
        /// </summary>
        /// <param name="inventory">Initialize with the inventory</param>
        public Terminal(IInventory inventory)
        { 
            _inventory = inventory;
            _productCodes = new StringBuilder();
        }

        /// <summary>
        /// This method scan the product
        /// </summary>
        /// <param name="item">Product code of the product</param>
        public void Scan(string item)
        {
            _productCodes.Append(item);
        }

        /// <summary>
        /// This method calculates the total price of all the scan items.
        /// </summary>
        /// <returns>Total Price</returns>
        public decimal Total()
        {
            var productItems = _productCodes.ToString().ToCharArray().GroupBy(eachItem => eachItem).ToDictionary(pair => pair.Key, pair => pair.Count());
            var totalPrice = 0.0M;
            foreach (var (productCode, pCodeCount) in productItems)
            {
                var priceFactory = new PriceGeneratorFactory().GetPriceGenerator(_inventory.GetProducts().FirstOrDefault(x => x.ProductCode == productCode));

                totalPrice += priceFactory.Generate(pCodeCount);
            }

            return totalPrice;
        }
    }
}
