﻿using System.Collections.Generic;
using ShoppingCart.Interface;

namespace ShoppingCart.Model
{
    /// <summary>
    /// Class to represent the inventory of the shop
    /// </summary>
    public class Inventory: IInventory
    {
        /// <summary>
        /// List of products in the shop
        /// </summary>
        public List<Product> Products { get; private set; } = new();

        /// <summary>
        /// Initializes the inventory class
        /// </summary>
        public Inventory()
        {
            Reset();
        }

        /// <summary>
        /// Method to reset all the products in the inventory
        /// </summary>
        public void Reset()
        {
            Products = new List<Product>();
        } 

        /// <summary>
        /// This method gets the inventory products
        /// </summary>
        /// <returns>List of products in the inventory</returns>
        public List<Product> GetProducts()
        {
            return Products;
        }
    }
}
