﻿namespace ShoppingCart.Model
{
    /// <summary>
    /// This class represents the volume size and volume price information of the product
    /// </summary>
    public class VolumeProductPrice
    {
        /// <summary>
        /// Initialize the volume product price 
        /// </summary>
        /// <param name="size">Volume size of the product</param>
        /// <param name="price">Volume price of the product</param>
        public VolumeProductPrice(int size, decimal price)
        {
            Size = size;
            Price = price;
        }

        /// <summary>
        /// Volume size of the product
        /// </summary>
        public int Size { get; set; }

        /// <summary>
        /// Volume price of the product
        /// </summary>
        public decimal Price { get; set; }
    }
}
