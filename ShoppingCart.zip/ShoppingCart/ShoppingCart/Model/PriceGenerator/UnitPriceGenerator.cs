﻿using ShoppingCart.Interface;

namespace ShoppingCart.Model.PriceGenerator
{
    /// <summary>
    /// Unit price generator class for the given product
    /// </summary>
    public class UnitPriceGenerator: IPriceGenerator
    {
        /// <summary>
        /// Unit price of the product
        /// </summary>
        private readonly decimal _unitPrice;

        /// <summary>
        /// Constructor to initialize the UnitPriceGenerator
        /// </summary>
        /// <param name="product"></param>
        public UnitPriceGenerator(Product product)
        {
            _unitPrice = product.Price;
        }

        /// <summary>
        /// Method to generate the total price based on number of products
        /// </summary>
        /// <param name="pCodeCount">Total number of products</param>
        /// <returns>Total price for scanned product based on number of product</returns>
        public decimal Generate(int pCodeCount)
        {
            return _unitPrice * pCodeCount;
        }
    }
}
