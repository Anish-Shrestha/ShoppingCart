﻿using ShoppingCart.Interface;

namespace ShoppingCart.Model.PriceGenerator
{
    /// <summary>
    /// Represents the factory class for the price generators
    /// </summary>
    public class PriceGeneratorFactory
    {
        /// <summary>
        /// Method to get the generator based on the product information
        /// </summary>
        /// <param name="product">Product model</param>
        /// <returns>Price Generator Interface</returns>
        public IPriceGenerator GetPriceGenerator(Product product)
        { 
            if (product.VolumeProductPrices is not null)
                return new VolumePriceGenerator(product);

            return new UnitPriceGenerator(product);
        }




    }
}
