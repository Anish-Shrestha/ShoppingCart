﻿using ShoppingCart.Interface;
using System.Collections.Generic;
using System.Linq;

namespace ShoppingCart.Model.PriceGenerator
{
    /// <summary>
    /// Represents the volume price generator class for given product
    /// </summary>
    public class VolumePriceGenerator: IPriceGenerator
    {
        /// <summary>
        /// List of volume product prices for the given product
        /// </summary>
        private readonly List<VolumeProductPrice> _volumeProductPrices;
      
        /// <summary>
        /// Unit price generator
        /// </summary>
        private readonly UnitPriceGenerator _unitPriceGenerator;

        /// <summary>
        /// Initializes the VolumePriceGenerator
        /// </summary>
        /// <param name="product">Product model</param>
        public VolumePriceGenerator(Product product)
        {
            _volumeProductPrices = product.VolumeProductPrices?.OrderByDescending(x=>x.Size).ToList();
            _unitPriceGenerator = new UnitPriceGenerator(product);
        }

        /// <summary>
        /// Method to generate the total price based on the different volume size and discount price
        /// </summary>
        /// <param name="pCodeCount">Total number of same product</param>
        /// <returns>Total Price</returns>
        public decimal Generate(int pCodeCount)
        {
            var price = 0.0M;
            foreach (var volumeProductPrice in _volumeProductPrices.Where(volumeProductPrice => pCodeCount >= volumeProductPrice.Size))
            {
                price += (pCodeCount / volumeProductPrice.Size) * volumeProductPrice.Price;
                pCodeCount %= volumeProductPrice.Size;
            }

            if (pCodeCount > 0)
                price += _unitPriceGenerator.Generate(pCodeCount);

            return price;
        }

    }
}
