﻿using Moq;
using ShoppingCart.Model;
using ShoppingCart.Model.PriceGenerator;
using Xunit;

namespace ShoppingCart.Test
{
    public class UnitPriceGeneratorTest
    {
        [Fact]
        public void Generate_UnitPrice_CorrectValue()
        {
            var mockProduct = new Mock<Product>('B', 12M);
            var generator = new UnitPriceGenerator(mockProduct.Object);
            Assert.Equal(120, generator.Generate(10));
        }
    }
}
