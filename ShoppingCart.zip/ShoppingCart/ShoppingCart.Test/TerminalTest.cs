using System.Collections.Generic;
using Moq;
using ShoppingCart.Interface;
using ShoppingCart.Model;
using Xunit;

namespace ShoppingCart.Test
{
    public class TerminalTest
    {
        private readonly List<Product> _productList;

        public TerminalTest()
        {
            _productList = new List<Product>
            {
                new('A', 2, 4, 7),
                new('B', 12),
                new('C', 1.25M, 6, 6),
                new('D', 0.15M)
            };
        }


        [Theory]
        [InlineData("ABCDABAA", 32.40)]
        [InlineData("CCCCCCC", 7.25)]
        [InlineData("ABCD", 15.40)] 
        public void Scan_TotalPrice_CorrectValue(string item, decimal expected)
        {
            var mockInventory = new Mock<IInventory>(); 

            mockInventory.Setup(x => x.GetProducts()).Returns(_productList); 

            ITerminal terminal = new Terminal(mockInventory.Object);

            foreach (var productCode in item.ToCharArray())
            {
                terminal.Scan(productCode.ToString());
            }
            
            Assert.Equal(terminal.Total(), expected);
        }
    }
}
