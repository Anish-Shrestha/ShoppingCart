﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using ShoppingCart.Model;
using ShoppingCart.Model.PriceGenerator;
using Xunit;

namespace ShoppingCart.Test
{
    public class VolumePriceGeneratorTest
    {
        [Fact]
        public void Generate_VolumePrice_CorrectValue()
        {
            var mockProduct = new Mock<Product>('A', 2M, 4, 7M);
            var generator = new VolumePriceGenerator(mockProduct.Object);
            Assert.Equal(7, generator.Generate(4));
        }
    }
}
